<style>
html, body {
    padding-top: 20px;
}

[data-role="dynamic-fields"] > .form-inline + .form-inline {
    margin-top: 0.5em;
}

[data-role="dynamic-fields"] > .form-inline [data-role="add"] {
    display: none;
}

[data-role="dynamic-fields"] > .form-inline:last-child [data-role="add"] {
    display: inline-block;
}

[data-role="dynamic-fields"] > .form-inline:last-child [data-role="remove"] {
    display: none;
}
</style>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<div class="page-content">	
	
	<?php if($this->session->flashdata('error')) { ?>
	<div class="alert alert-danger">
		<a href="#" class="close" data-dismiss="alert">&times;</a>
		<?php echo $this->session->flashdata('error') ;?>
	</div>
	<?php } 
	if($this->session->flashdata('success')) { ?>
	<div class="alert alert-success">
		<button class="close" data-dismiss="alert">×</button>
		<?php echo $this->session->flashdata('success') ;?>
	</div>
	<?php } 
	if($this->session->flashdata('info')) { ?>
	<div class="alert alert-info">
		<a href="#" class="close" data-dismiss="alert">&times;</a>
		<?php echo $this->session->flashdata('info') ;?>
	</div>
	<?php } ?>
	<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			Gasoline Receipt Entry<small></small>
			</h3>
			<div class="page-bar">

	<!-- Widget -->
	<!--div class="widget widget-heading-simple widget-body-gray">
		<div class="widget-body center">
			<p class="lead margin-none">Unlimited Columns &amp; Expandable Rows. Tables for Desktop, Tablet &amp; Mobile. Resize your browser to try them.</p>
		</div>
	</div-->
		
	<h5 class="text-uppercase strong separator bottom margin-none"></h5>
	<form class="form-horizontal" action="<?php echo base_url('admin/enduser/savegasoline');?>" id="edit_page" method="post" autocomplete="off">
	<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div data-role="dynamic-fields">
                <div class="form-inline">

                    
                    <div class="form-group">
                        <label class="sr-only" for="field-value">Amount</label>
                        <input type="text" class="form-control" id="amount[]" name="amount[]" value="" placeholder="Amount">
                    </div>
					 
					 <div class="form-group">
                        <label class="sr-only" for="field-value">Drops Type</label>
						<select class="form-control" name="type[]" id="type[]">
						<option value="regular" selected="selected">REGULAR</option>
						<option value="super">SUPER</option>
						<option value="diesel">DIESEL</option>
						<option value="propane">PROPANE</option>
						</select>
						<!--
                        <input class="form-control" type="radio" name="type[]" id="type[]"  checked="checked" value="drops">Drops&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="form-control" type="radio" name="type[]" id="type[]" value="payout">Payout
                   -->
				   </div>
                    <button class="btn btn-danger" data-role="remove">
                        <span class="glyphicon glyphicon-remove"></span>
                    </button>
                    <button class="btn btn-primary" data-role="add">
                        <span class="glyphicon glyphicon-plus"></span>
                    </button>
                </div>  <!-- /div.form-inline -->
            </div>  <!-- /div[data-role="dynamic-fields"] -->
        </div>  <!-- /div.col-md-12 -->
    </div>  <!-- /div.row -->
	<div>&nbsp;</div>
	<button type="submit" name='save_page' value='Save' class="btn green btn-primary glyphicons circle_ok"><i></i>Add</button>
</div>
	</form>
	
	<div>&nbsp;</div>
	<div>
	<table class="footable table table-striped table-bordered table-white table-primary">
	
		<!-- Table heading -->
		<thead>
			<tr>
				<th>Drops</th>
				<th data-class="Title">REGULAR</th>
				<th data-hide="Heading,tablet">SUPER</th>
				<th data-hide="Heading,tablet">DIESEL</th>
				<th data-hide="Heading,tablet">PROPANE</th>
				<th data-hide="Heading,tablet">GAS SALES</th>
				<th data-hide="Heading,tablet">TOTAL</th>
				
			
				
				
			</tr>
		</thead>
		<!-- // Table heading END -->
		
		<!-- Table body -->
		<tbody>
		
			<!-- Table row -->
			 <?php
			
				?>		
						
	<tr class="gradeX">
				 <td>Open</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>	
						
	<tr class="gradeX">
				 <td>Received</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>	

<tr class="gradeX">
				 <td>Total</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>

  <tr class="gradeX">
				 <td>sale</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>	

<tr class="gradeX">
				 <td>Balance</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>

<tr class="gradeX">
				 <td>Veeder Root</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>

<tr class="gradeX">
				 <td>Difference</td>
				 <td></td>
					 <td></td>
					 <td></td>
					 <td></td>
					   <td></td>
						 <td></td>
					</tr>						
						
					
				<tr><td colspan="3">Total:&nbsp;$ 000.000</td><td colspan="3">Total:&nbsp;$ 0000.000</td></tr>
			   
			
			<!-- // Table row END -->
			
			
		</tbody>
		<!-- // Table body END -->
		
	</table>
	<!-- // Table END -->
	</div>
	
	
</div>
</div>
</div>
	
	<script type="text/javascript">
$(function() {
    // Remove button click
    $(document).on(
        'click',
        '[data-role="dynamic-fields"] > .form-inline [data-role="remove"]',
        function(e) {
            e.preventDefault();
            $(this).closest('.form-inline').remove();
        }
    );
    // Add button click
    $(document).on(
        'click',
        '[data-role="dynamic-fields"] > .form-inline [data-role="add"]',
        function(e) {
            e.preventDefault();
            var container = $(this).closest('[data-role="dynamic-fields"]');
            new_field_group = container.children().filter('.form-inline:first-child').clone();
            new_field_group.find('input').each(function(){
                $(this).val('');
            });
            container.append(new_field_group);
        }
    );
});
</script>