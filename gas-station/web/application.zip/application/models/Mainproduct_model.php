<?php
class Mainproduct_model extends CI_Model{
	protected $_table_name = 'price';
	protected $_order_by = 'id';
	protected static $db_fields = array('id', 'pid', 'price', 's_price', 'c_id', 'date_created', 'date_modified');
	
	public $id;
	public $pid; 
	public $price; 
	public $s_price; 
	public $c_id; 
	public $date_created; 
	public $date_modified; 
	 
	
		
	
	//public $delete_status; //1 if delte

	public function __construct()
	{
		parent::__construct();
		$this->load->database();

	}

	public function savePage($id=NULL,$table='price')
	{
		
		
		$data 	= $this->array_from_post(self::$db_fields);	
		
		
		if($id)
		{
			
            
			$table = 'price';
		
			//die('error');
			
			$price = $this->input->post("price");
			$s_price = $this->input->post("s_price");
		    $modified_date  = date("Y-m-d H:i:s", time());
		
			$modified_date= date("Y-m-d H:i:s", time());
			
			$data = array('price'=> $price, 's_price'=> $s_price,  'date_modified'=> $modified_date);
			
			$this->db->where('id', $id);
			
			$this->db->update($table ,$data);
			

			
			
			if($last_id !== 0){
				return true;
				$this->session->set_flashdata('success', '<div class="alert alert-success display-hide"><span>Record Deleted SuccesFully</span></div> ');
			}else{
				return false;
			}
			//$this->save($data, $id);

		} else {
		
		
			//$data['slug'] 	=	$this->create_unique_slug($title);			
			//$data['status']			=	'1';
			$status =	$this->input->post("status");
		
			$data['date_created']		=	time();
            $data['date_created']  = date("Y-m-d H:i:s", time());	
            $Company_id = unserialize($this->session->userdata('admin'));
			$comp_id = $Company_id['id'];
            $data['c_id']		= $comp_id;			
			//$this->save($data, $id);
			$last_id = $this->db->insert($table ,$data);
			$sql= $this->db->last_query();
		    $insert_id = $this->db->insert_id();
			
// insert code for price table start
            $insert_id = $this->db->insert_id();
			$table1 = 'price';
		
			//$product_id =	$this->db->insert_id();
			 $Company_id = unserialize($this->session->userdata('admin'));
			 $comp_id = $Company_id['id'];
			
			$price =	$this->input->post("p_price");
			$s_price =	$this->input->post("s_price");
			
			
			$created_date= date("Y-m-d H:i:s", time());
			
			$data1 = array('id'=> NULL,	'pid'=> $insert_id,	'price'=> $price, 's_price'=> $s_price,	'c_id'=> $comp_id ,	'date_created'=> $created_date);
			
			$this->db->insert($table1, $data1); 
		    $sql1= $this->db->last_query();
// insert code for price table ends
			
			if($last_id !== 0){
				return true;
			}else{
				return false;
			}
			//$id = (empty($id)) ? $this->db->insert_id() : $id; 					
			
		}
		//$obj = $this->get2($id);			
		//return true;			
	}
	
	
	public function price_insert($data) {
$data1 = array(
           'price' => $data,
        );
 // Query to insert data in database
  $this->db->where('id', '1');
  $this->db->update('price', $data1);
  if ($this->db->affected_rows() > 0) {
     return true;
    }
   else {
   return false;
   }
  } 


	public function getUsers($account_type = "All") 
	{
		if($account_type != "All"){			
			$this->db->where("account_type = '{$account_type}' and delete_status = 0");
		} else {
			$this->db->where("delete_status = 0");
		}
		$users = $this->get2(NULL,false);
		return $users;
	}

	public function getPage($id) 
	{
		$this->db->where("id = '{$id}'");		
		$page = $this->get();
		
		return $page[0];
	}
	
	public function getallPage() 
	{
		$this->db->where("status = '1'");
		$this->db->order_by("position",'ASC');
		$page = $this->get2();
		return $page;
	}

	public function printStatus()
	{
		switch($this->status)
		{
			case 1: 
				return "Active";
			default:
				return "Disabled";
		}
	}

	public function deletePage($id)
	{
		$result = $this->delete($id);
		$this->db->delete('product', array('id' => $id));
		$this->db->delete('price', array('pid' => $id));

		return $result;
		
		//$this->db->where('p_id', $id);
        //$result1=$this->db->delete('price');


	}

	public function getPrice($id) 
	{
	/*	$this->db->where("id = '{$id}'");		
		$page = $this->get();
		
		return $page[0];
		*/
			$Company_id = unserialize($this->session->userdata('admin'));
		    $cid1 = $Company_id['id'];
			
			
			$this->db->select('*');
$this->db->from('price');
$this->db->join('product', 'product.id = price.pid');
			
			
//$this->db->select('*');
//$this->db->from('price');

$this->db->where("cd_price.c_id = '{$cid1}'");
$query = $this->db->get();
//$query1 = $this->db->last_query();
$page = $query->result();

return $page;
//$query = $this->db->get();


	}
	
}


?>