<?php
	$config['full_tag_open'] = '<div class="pagination_div_on_listpg" align="center">';
	$config['full_tag_close'] = '</div>';
	$config['first_link'] = 'First';
	$config['first_tag_open'] = '<div class="first_prev">';
	$config['first_tag_close'] = '</div>';

	$config['last_link'] = 'Last';
	$config['last_tag_open'] = '<div class="scnd_last">';
	$config['last_tag_close'] = '</div>';

	$config['next_link'] = 'Next';
	$config['next_tag_open'] = '<div class="scnd_last">';
	$config['next_tag_close'] = '</div>';

	$config['prev_link'] = 'Previous';
	$config['prev_tag_open'] = '<div class="first_prev">';
	$config['prev_tag_close'] = '</div>';

	$config['cur_tag_open'] = '<span><a href="javascript:void(0);">';
	$config['cur_tag_close'] = '</a></span>';

	$config['num_tag_open'] = '<span>';
	$config['num_tag_close'] = '</span>';



	






?>