<?php
	$config['full_tag_open'] 	= '<div class="pagination-box"><ul class="list-inline">';
	$config['full_tag_close'] 	= '</ul></div>';
	$config['first_link'] 		= '<li class="active"><a href="#"><span>First</span></a></li>';
	$config['first_tag_open'] 	= '<li class="first_prev">';
	$config['first_tag_close'] 	= '</li>';

	$config['last_link'] = 'Last';
	$config['last_tag_open'] = '<li class="active">';
	$config['last_tag_close'] = '</li>';

	$config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
	$config['next_tag_open'] = '<li class="scnd_last">';
	$config['next_tag_close'] = '</li>';

	$config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
	$config['prev_tag_open'] = '<li class="first_prev">';
	$config['prev_tag_close'] = '</li>';

	$config['cur_tag_open'] = '<li class="active"><span><a href="javascript:void(0);">';
	$config['cur_tag_close'] = '</a></span></li>';

	$config['num_tag_open'] = '<li><span>';
	$config['num_tag_close'] = '</span></li>';



	






?>